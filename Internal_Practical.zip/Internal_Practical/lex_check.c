#include<stdio.h>

int main()
{
    int a = 0;
    printf("Hello, World!");
    return 0;
}